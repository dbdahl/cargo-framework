#' @docType package
#' @usage NULL
#' @useDynLib X@X, .registration = TRUE
NULL
