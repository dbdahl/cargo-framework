library(testthat)
library(cargo)

test_check("cargo")
