// Dummy file to prevent CRAN warnings:
//   "Subdirectory 'src' contains no source files"
//   "ISO C forbids an empty translation unit"
const char R_CARGO_VERSION[] = "0.4.9";
