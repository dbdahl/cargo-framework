void R_init_X@X_librust(void *dll);
void R_init_X@X(void *dll) { R_init_X@X_librust(dll); }
